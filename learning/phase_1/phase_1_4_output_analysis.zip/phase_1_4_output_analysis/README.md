# Practicing Agents Output Validation through Building an AI SQL Query Generation System

This project demonstrates the importance of output validation in the business scenario highlighting the probablistic characteristiques of LLMs raw output.


The main goal of this project is to measure model's ability to generate validated output correctly. The project is not interested in evaluating the model or ensuring that the output is correct. The main purpose to examine of models to generate validated & rules-aligned models.

The app evaluates four Groq models:

- `llama-3.1-8b-instant`
- `llama-3.3-70b-versatile`
- `qwen/qwen3-32b`
- `openai/gpt-oss-120b`


---

## Task Description

### Objective
Evaluate whether LLM responses can be safely converted into validated outputed before being used by an application.

The models asked to:

1. Outputting a SQL query from a given natural language query assumed to be entered by the user.
2. List the tables used in the query out of the global set of all tables.
3. Only respond to safe query types such as `SELECT` ignoring queries that may affect the data `UPDATE`, `DELETE`, etc.
4. Ignore queries searching for sensitive data like `passwords`, `credit cards data`, etc.


### Validation
After that, the output is getting evaluated at these three subsequent layers:

1. schema validation        : Validating the model's capability to generate the required response format.
2. semantic validation      : Validating that the model outputs logical & coherent output with no inconsistencies.
3. Business rules validation: Validating the core business rules required by the the app & instructed to the model through prompt engineering.


### Self Correction
If the model cannot generate a validated output, a feedback loop tells the model about its errors & gives it the query again in order to make it corrects its previous output. This process is done for three times, if the model falls in validation for three times, the sample is considered not validated & a simple string message considered as a simple default fallback.


### Measurements
To evaluate the models capability to generate validated outputs, we collected a simple dataset contains 30 samples. Each sample has the following:
- id: Id of the sample
- complexity: Complexity of the sample
- query: The natural language query goes to the model
- required_query_type: the expected query type
- tables_used: the expected tables_used

The final mesurements that the model outputed measured on were
- validation_score: ratio of validated samples over all the total samples.
- query_type_score: score of the model's predicted query type over all samples.
- tables_used_score: score of the model's predicted tables_used over all samples.



### Example

Example data sample:

```json
{
    "id": 1,
    "complexity": "low",
    "query": "Show all customers.",
    "required_query_type": "SELECT",
    "tables_used": ["customers"]
}
```

Model Structured Output:

```json
{
    "sql_query": "SELECT * FROM customers",
    "required_query_type": "SELECT",
    "tables_used": [
        "customers"
    ]
}
```

Final Saved Result
```json
{
    "validated": true,
    "sample_id": 1,
    "sample_query": "Show all customers.",
    "sample_complexity": "low",
    "sql_query": "SELECT * FROM customers",
    "required_query_type": "SELECT",
    "tables_used": [
        "customers"
    ]
}
```

---


## Results


