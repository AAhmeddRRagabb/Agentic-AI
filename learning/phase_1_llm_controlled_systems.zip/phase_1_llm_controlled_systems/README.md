# Phase 1: LLM Controlled Systems

This phase aims to build production-qualityLLMinteraction layerwith structuredoutputs, validation, self
correction, costtracking,andobservability.

## Phase Topics

### 2. LLM API Architecture

Learning LLMs basic concepts:

* How to interact with LLM providers.

* Model selection tradeoffs (capability - cost - latency - tokens processing)

* How to control model behavior through inference parameters (temperature - max output tokens - top p)




## Phase Structure
The phase contains the following sections

### LLMs
All about LLMs (invoking - prompting)